#include <GL/glut.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
 
#define WIDTH 640
#define HEIGHT 480
 
 
 
void reshape(int width, int height){
    glViewport(0,0,wid 
void Timer(int ex){
    glutPostRedisplay();
    glutTimerFunc(15,Timer,0);
}
 
int k = 20;

void circle(int p,int m){
    int x = 0, y, d, r;
    r = m;
    y = r;
    d = 3 - 2 * r;
    while(x <= y){
        glVertex2i(x, y + p);
        glVertex2i(y, x + p);
        glVertex2i(-x, y + p);
        glVertex2i(-y, x + p);
        glVertex2i(-x, -y + p);
        glVertex2i(-y, -x + p);
        glVertex2i(y, -x + p);
        glVertex2i(x, -y + p);
        if(d < 0){
            d = d + 4 * x + 6;
        }else{
            d = d + 4 * (x - y) + 10;
            y--;
        }
        x++;
    }
}
 
int r = 100,flag = 0;
 
void display(void){
 
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glColor4f(1.0, 0.0, 0.0, 0.0);
    glBegin(GL_POINTS);
 
 
    circle(k, r);
 
 
    if(flag == 0){
        if((k + r) <= 240){
            k = k + 10;
        }
 
        if((k + r) >= 240){
            flag = 1;
        }
    }
 
    if(flag == 1){
        k = k - 10;
 
        if((k - r) <= -240){
            flag = 0;
        }
    }
 
    glEnd();
    glutSwapBuffers(); 
}
 
void idle(void){
    
}
 
int main(int argc, char **argv){
    glutInit(&argc,argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);
    glutInitWindowPosition(0,0);
    glutInitWindowSize(WIDTH,HEIGHT);
    glutCreateWindow(argv[0]);
    init();
    glutIdleFunc(idle);
    glutReshapeFunc(reshape);   
    glutDisplayFunc(display);
    glutTimerFunc(0,Timer,0);
    glutMainLoop();
    return(1);
}
 
void Timer(int ex){
    glutPostRedisplay();
    glutTimerFunc(15,Timer,0);
}
 
int k = 20;

void circle(int p,int m){
    int x = 0, y, d, r;
    r = m;
    y = r;
    d = 3 - 2 * r;
    while(x <= y){
        glVertex2i(x, y + p);
        glVertex2i(y, x + p);
        glVertex2i(-x, y + p);
        glVertex2i(-y, x + p);
        glVertex2i(-x, -y + p);
        glVertex2i(-y, -x + p);
        glVertex2i(y, -x + p);
        glVertex2i(x, -y + p);
        if(d < 0){
            d = d + 4 * x + 6;
        }else{
            d = d + 4 * (x - y) + 10;
            y--;
        }
        x++;
    }
}
 
int r = 100,flag = 0;
 
void display(void){
 
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glColor4f(1.0, 0.0, 0.0, 0.0);
    glBegin(GL_POINTS);
 
 
    circle(k, r);
 
 
    if(flag == 0){
        if((k + r) <= 240){
            k = k + 10;
        }
 
        if((k + r) >= 240){
            flag = 1;
        }
    }
 
    if(flag == 1){
        k = k - 10;
 
        if((k - r) <= -240){
            flag = 0;
        }
    }
 
    glEnd();
    glutSwapBuffers(); 
}
 
void idle(void){
    
}
 
int main(int argc, char **argv){
    glutInit(&argc,argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);
    glutInitWindowPosition(0,0);
    glutInitWindowSize(WIDTH,HEIGHT);
    glutCreateWindow(argv[0]);
    init();
    glutIdleFunc(idle);
    glutReshapeFunc(reshape);   
    glutDisplayFunc(display);
    glutTimerFunc(0,Timer,0);
    glutMainLoop();
    return(1);
}