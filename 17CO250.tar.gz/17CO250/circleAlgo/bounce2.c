#include <GL/glut.h>
#include <stdio.h>

int r, incr1 = 0, incr2 = 0;
int flag1 = 1, flag2 = 1;
int xc = 0, yc = 0;



void drawPoints(int x, int y, int xc, int yc){
    glBegin(GL_POINTS);
    
    glVertex2i(x + xc + incr2, y + yc + incr1);
    glVertex2i(x + xc + incr2, -y + yc + incr1);
    glVertex2i(-x + xc + incr2, y + yc + incr1);
    glVertex2i(-x + xc + incr2, -y + yc + incr1);

    glVertex2i(y + xc + incr2, x + yc +incr1);
    glVertex2i(y + xc + incr2, -x + yc + incr1);
    glVertex2i(-y + xc + incr2, x + yc + incr1);
    glVertex2i(-y + xc + incr2, -x + yc + incr1);

    glEnd();

}


void drawCircle(int xc, int yc, int r){
    int x = 0, y = r;
    int d = 3 - 2 * r;
    while(y >= x){
        x++;
        if(d > 0){
            y--;
            d = d + 4 * (x - y) + 10;
        }else{
            d = d + 4 * x + 6;
        }
        drawPoints(x, y, xc, yc);
    }
}


void getAns(){
    glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(0.0, 1.0, 0.0);
    

    drawCircle(xc, yc, r);

    if(incr1 <= 500 && flag1 == 1){
        incr1 += 6;
    }else if(incr1 > 500 && flag1 == 1){
        incr1 -= 6;
        flag1 = 0;
    }else if(incr1 <= 500 && flag1 == 0 && incr1 >= -500){
        incr1 -= 6;
    }else if(incr1 < -500 && flag1 == 0){
        incr1 += 6;
        flag1 = 1;
    }

    if(incr2 <= 500 && flag2 == 1){
        incr2 += 2;
    }else if(incr2 > 500 && flag2 == 1){
        incr2 -= 2;
        flag2 = 0;
        flag1 = !flag1;
    }else if(incr2 <= 500 && flag2 == 0 && incr2 >= -500){
        incr2 -= 2;
    }else if(incr2 < -500 && flag2 == 0){
        incr2 += 2;
        flag2 = 1;
        flag1 = !flag1;
    }

    glutSwapBuffers(); 
    //glFlush();
}

void init(){
    glClearColor(0.0, 0.0, 0.0, 0.0);
    glPointSize(1.2);
    glMatrixMode(GL_PROJECTION);
    gluOrtho2D(-500.0, 500.0, -500.0, 500.0);
}

void Timer(int ex){
    glutPostRedisplay();
    glutTimerFunc(10,Timer,0);
}

int main(int argc, char** argv){

    printf("Give radius of circle\n");
    scanf("%d", &r);

    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(500, 500);
    glutCreateWindow("Bresenham Circle Algo");
    init();
    glutDisplayFunc(getAns);
    glutTimerFunc(0,Timer,0);
    glutMainLoop();

    return 0;
}

