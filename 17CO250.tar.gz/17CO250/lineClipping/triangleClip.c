#include <GL/glut.h>
#include <stdio.h>
#include <stdlib.h>
#include<math.h>

float a1, b1, a2, b2, a3, b3;
float xleft, xright, ylow, yhigh;


void init(){
	glClearColor(0.0, 0.0, 0.0, 0.0);
	glMatrixMode(GL_PROJECTION);
	glPointSize(1.5);
    gluOrtho2D(-400,400,-400,400);
}

void makeLine(float t1, float p1, float t2, float p2){
    glBegin(GL_LINES);
    glVertex2i(t1, p1);
    glVertex2i(t2, p2);
    glEnd();
}


int getPos(float px, float py){
	int a = 8, b = 4, r = 2, l = 1;
	int ans = 0;
	if(px < xleft){
		ans |= l;
	}else if(px > xright){
		ans |= r;
	}
	if(py < ylow){
		ans |= b;
	}else if(py > yhigh){
		ans |= a;
	}
	return ans;
}

void clip(float px1, float py1, float px2, float py2){
    int a = 8, b = 4, r = 2, l = 1;
	int p1 = getPos(px1, py1);
	int p2 = getPos(px2, py2);
	if(p1 == 0 && p2 == 0){

		glColor3f(0.0, 1.0, 0.0);

		glBegin(GL_LINES);
		glVertex2i(px1, py1);
		glVertex2i(px2, py2);
		glEnd();

		return;
	}

	float xnew = 0.0, ynew = 0.0;

	if( (p1&p2) != 0){
		return;
	}

	int p = (p1 != 0) ? p1 : p2;

	if((p&l)){
		xnew = xleft;
		ynew = py1 + (py2 - py1) * (xleft - px1) / (px2 - px1);
	}else if((p&r)){
		xnew = xright;
		ynew = py1 + (py2 - py1) * (xright - px1) / (px2 - px1); 
	}else if((p&a)){
		ynew = yhigh;
		xnew = px1 + (px2 - px1) * (yhigh - py1) / (py2 - py1);
	}else if((p&b)){
		ynew = ylow;
		xnew = px1 + (px2 - px1) * (ylow - py1) / (py2 - py1); 
	}

	if(p == p1){
		px1 = xnew, py1 = ynew;
	}else{
		px2 = xnew, py2 = ynew;
	}

    if(p2 != 0){
        p = p2;
        if((p&l)){
		    xnew = xleft;
		    ynew = py1 + (py2 - py1) * (xleft - px1) / (px2 - px1);
	    }else if((p&r)){
	    	xnew = xright;
	    	ynew = py1 + (py2 - py1) * (xright - px1) / (px2 - px1); 
	    }else if((p&a)){
	    	ynew = yhigh;
	    	xnew = px1 + (px2 - px1) * (yhigh - py1) / (py2 - py1);
	    }else if((p&b)){
	    	ynew = ylow;
	    	xnew = px1 + (px2 - px1) * (ylow - py1) / (py2 - py1); 
	    }
        px2 = xnew, py2 = ynew;
    }

    p1 = getPos(px1, py1);
	p2 = getPos(px2, py2);

    if(p1 != 0 && p2 != 0){
        return;
    }

	
	glColor3f(0.0, 1.0, 0.0);
	glBegin(GL_LINES);
	glVertex2i(px1, py1);
	glVertex2i(px2, py2);
	glEnd();
}

void displayText(){

	glColor3f(1,1,1);
	glRasterPos2f(0, 250);
	int i;
	char string[100] = "Triangle Clipping";
    int length = 17;
	for (i = 0; i < length; i++) {
	glutBitmapCharacter(GLUT_BITMAP_9_BY_15, string[i]);
	}

}


void getAns(){
	
	glClear(GL_COLOR_BUFFER_BIT);

	glColor3f(1.0, 0.0, 1.0);

	glBegin(GL_LINES);
    glVertex2i(xleft,ylow);
    glVertex2i(xleft,yhigh);
    glEnd();

	glBegin(GL_LINES);
    glVertex2i(xright,ylow);
    glVertex2i(xright,yhigh);
    glEnd();

	glBegin(GL_LINES);
    glVertex2i(xleft,ylow);
    glVertex2i(xright,ylow);
    glEnd();

	glBegin(GL_LINES);
    glVertex2i(xleft,yhigh);
    glVertex2i(xright,yhigh);
    glEnd();


	glColor3f(1.0, 0.0, 0.0);

	makeLine(a1, b1, a2, b2);
	makeLine(a1, b1, a3, b3);
	makeLine(a2, b2, a3, b3);
	

	clip(a1, b1, a2, b2);
    clip(a1, b1, a3, b3);
    clip(a2, b2, a3, b3);

    displayText();
	glFlush();


}



int main(int argc,char* argv[]){

	printf("Enter traingle coordinates as x1 y1, x2 y2, x3 y3\n");
	scanf("%f%f%f%f%f%f",&a1, &b1, &a2, &b2, &a3, &b3);
	
    printf("enter xmin xmax ymin ymax\n");
    scanf("%f%f%f%f", &xleft, &xright, &ylow, &yhigh);
	
	glutInit(&argc,argv);
	glutInitDisplayMode(GLUT_SINGLE|GLUT_RGB);
	glutInitWindowSize(800,800);
	glutInitWindowPosition(0,0);
	glutCreateWindow("Triangle Clip Algo");
	init();
	glutDisplayFunc(getAns);
	glutMainLoop();


}