#include <GL/glut.h>
#include <stdio.h>
#include <stdlib.h>
#include<math.h>

float a1, b1, a2, b2;
float xleft, xright, ylow, yhigh;


void init(){
	glClearColor(0.0, 0.0, 0.0, 0.0);
	glMatrixMode(GL_PROJECTION);
	glPointSize(1.5);
    gluOrtho2D(-400,400,-400,400);
}

int getPos(float px, float py){
	int a = 8, b = 4, r = 2, l = 1;
	int ans = 0;
	if(px < xleft){
		ans |= l;
	}else if(px > xright){
		ans |= r;
	}
	if(py < ylow){
		ans |= b;
	}else if(py > yhigh){
		ans |= a;
	}
	return ans;
}

void clip(){
	int a = 8, b = 4, r = 2, l = 1;
	int p1 = getPos(a1, b1);
	int p2 = getPos(a2, b2);
	if(p1 == 0 && p2 == 0){

		glColor3f(0.0, 1.0, 0.0);

		glBegin(GL_LINES);
		glVertex2i(a1, b1);
		glVertex2i(a2, b2);
		glEnd();

		return;
	}

	float xnew = 0.0, ynew = 0.0;

	if( (p1&p2) != 0){
		return;
	}

	int p = (p1 != 0) ? p1 : p2;

	if((p&l)){
		xnew = xleft;
		ynew = b1 + (b2 - b1) * (xleft - a1) / (a2 - a1);
	}else if((p&r)){
		xnew = xright;
		ynew = b1 + (b2 - b1) * (xright - a1) / (a2 - a1); 
	}else if((p&a)){
		ynew = yhigh;
		xnew = a1 + (a2 - a1) * (yhigh - b1) / (b2 - b1);
	}else if((p&b)){
		ynew = ylow;
		xnew = a1 + (a2 - a1) * (ylow - b1) / (b2 - b1); 
	}

	if(p == p1){
		a1 = xnew, b1 = ynew;
	}else{
		a2 = xnew, b2 = ynew;
	}

	
	glColor3f(0.0, 1.0, 0.0);
	glBegin(GL_LINES);
	glVertex2i(a1, b1);
	glVertex2i(a2, b2);
	glEnd();

}


void getAns(){
	
	glClear(GL_COLOR_BUFFER_BIT);

	glColor3f(1.0, 0.0, 1.0);

	glBegin(GL_LINES);
    glVertex2i(xleft,ylow);
    glVertex2i(xleft,yhigh);
    glEnd();

	glBegin(GL_LINES);
    glVertex2i(xright,ylow);
    glVertex2i(xright,yhigh);
    glEnd();

	glBegin(GL_LINES);
    glVertex2i(xleft,ylow);
    glVertex2i(xright,ylow);
    glEnd();

	glBegin(GL_LINES);
    glVertex2i(xleft,yhigh);
    glVertex2i(xright,yhigh);
    glEnd();


	glColor3f(1.0, 0.0, 0.0);

	glBegin(GL_LINES);
	glVertex2i(a1, b1);
	glVertex2i(a2, b2);
	glEnd();

	clip();
	float tmp = a1;
	a1 = a2, a2 = tmp;
	tmp = b1, b1 = b2, b2 = tmp;
	clip();

	glFlush();


}


int main(int argc,char* argv[]){

	printf("Enter line coordinates as x1 y1 , x2 y2\n");
	scanf("%f%f%f%f",&a1, &b1, &a2, &b2);
	
    printf("enter xmin xmax ymin ymax\n");
    scanf("%f%f%f%f", &xleft, &xright, &ylow, &yhigh);
	
	glutInit(&argc,argv);
	glutInitDisplayMode(GLUT_SINGLE|GLUT_RGB);
	glutInitWindowSize(800,800);
	glutInitWindowPosition(0,0);
	glutCreateWindow("Cohen Sutherland Algo");
	init();
	glutDisplayFunc(getAns);
	glutMainLoop();


}