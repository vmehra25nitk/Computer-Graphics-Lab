#include <GL/glut.h>
#include <stdio.h>
#include <stdlib.h>
#include<math.h>

float *x,*y;
float sx = 0.0,sy = 0.0;
float px1, py1, px2, py2;
float angle = 0.0;

void display(){
	
    glBegin(GL_LINES);
    glColor3f(1, 0, 0);
    glVertex2f(px1 * sx, py1 * sy);
    glVertex2f(px2 * sy, py2 * sy);
    glEnd();

    glBegin(GL_LINES);
    glColor3f(0, 1, 0);
    glVertex2f(px1, py1);
    glVertex2f(px2, py2);
    glEnd();
    glFlush();
}


void init(){
	glClearColor(0.0, 0.0, 0.0, 0.0);
	glClear(GL_COLOR_BUFFER_BIT);
	gluOrtho2D(-300,300,-300,300);
}

int main(int argc,char* argv[]){

	printf("Enter x1, y1, x2, y2\n");
	scanf("%f%f%f%f", &px1, &py1, &px2, &py2);

    printf("Enter scaling factor \n");
    scanf("%f", &sx);
    sy = sx;
	
	glutInit(&argc,argv);
	glutInitDisplayMode(GLUT_SINGLE|GLUT_RGB);
	glutInitWindowSize(600,600);
	glutInitWindowPosition(0,0);
	glutCreateWindow("Translate-Line");
	init();
	glutDisplayFunc(display);
	glutMainLoop();


}