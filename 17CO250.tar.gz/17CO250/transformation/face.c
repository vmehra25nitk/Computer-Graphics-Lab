#include<GL/glut.h>
#include<stdio.h> 
#include<stdlib.h>

float sizeFactor = 1, shiftFactor = 0;
float rFace = 60, rEye = 15, rEyeball = 7, rNose = 10, rLip = 30;
float rotate = 0;
int pxc = 0, pyc = 0;

void display(){    
    glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(0.0, 1.0, 0.0);
    glFlush();
}




void rotateEye(int x){
    rotate += x;
}

void reset(){
    glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(0.0, 1.0, 0.0);
    glFlush();
}

void resizeRadius(){
    rFace *= sizeFactor;
    rEye *= sizeFactor;
    rEyeball *= sizeFactor;
    rNose *= sizeFactor;
    rLip *= sizeFactor;
}

void shift(int x);

void drawFace(int pxc, int pyc);


void keyboard(unsigned char key, int x, int y){
    switch(key){
        
        case 'a':
            rotateEye(1);
            break;
        case 'b':
            rotateEye(-1);
            break;

        case 'c':
            reset();
            sizeFactor = 1.5;
            resizeRadius();
            drawFace(pxc, pyc);
            break;
        case 'd':
            reset();
            sizeFactor = (float)1.0/1.5;
            resizeRadius();
            drawFace(pxc, pyc);
            break;

        case 'e':
            shift(1);
            break;
        case 'f':
            shift(-1);
            break;

        case 'r':
            reset();
            break;

        case 'x':
            exit(0);
            break; 

    }
}

void drawPoints(int x, int y, int xc, int yc){
    glBegin(GL_POINTS);
       
    glVertex2i(x + xc + shiftFactor, y + yc);
    glVertex2i(x + xc + shiftFactor, -y + yc);
    glVertex2i(-x + xc + shiftFactor, y + yc);
    glVertex2i(-x + xc + shiftFactor, -y + yc);

    glVertex2i(y + xc + shiftFactor, x + yc);
    glVertex2i(y + xc + shiftFactor, -x + yc);
    glVertex2i(-y + xc + shiftFactor, x + yc);
    glVertex2i(-y + xc + shiftFactor, -x + yc);

    glEnd();

}

void drawCircle(int xc, int yc, float r){
    float x = 0, y = r;
    float d = 3 - 2 * r;
    while(y >= x){
        x++;
        if(d > 0){
            y--;
            d = d + 4 * (x - y) + 10;
        }else{
            d = d + 4 * x + 6;
        }
        drawPoints(x, y, xc, yc);
    }
}


void drawFace(int cx, int cy){
    pxc = cx, pyc = cy;
    drawCircle(pxc, pyc, rFace);
    drawCircle(pxc, pyc, rNose);
    drawCircle(pxc + rFace/2, pyc + rFace/2, rEye);
    drawCircle(pxc - rFace/2, pyc + rFace/2, rEye);
    drawCircle(pxc + rFace/2, pyc + rFace/2 - rEye/2, rEyeball);
    drawCircle(pxc - rFace/2, pyc + rFace/2 - rEye/2, rEyeball);
    glFlush();
}

void makeFace(int cx, int cy){

    glBegin(GL_POINTS);
    cy = 500 - cy;

    drawFace(cx, cy);

    printf("%d %d\n", cx, cy);
    glVertex2i(cx, cy);
    glEnd(); 
    glFlush(); 
}


void mouse(int button, int state, int x, int y){
    switch(button){
	    case GLUT_LEFT_BUTTON:
		    if(state==GLUT_DOWN){
			    makeFace(x, y);
            }
		    break;
	    case GLUT_RIGHT_BUTTON:
		    if(state==GLUT_DOWN){
			    exit(0);
            }
		    break;
	    default:
		    break;
	}
}

void shift(int x){
    reset();
    shiftFactor += x;
    drawFace(pxc, pyc);
}

void init(){
    glClearColor(0.0, 0.0, 0.0, 0.0);
    glMatrixMode(GL_PROJECTION);
    glPointSize(2);
    gluOrtho2D(0, 500.0, 0, 500.0);
}

int main(int argc,char** argv){

    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(500, 500);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutCreateWindow("Face");
    init();
    glutDisplayFunc(display);
    glutKeyboardFunc(keyboard);
    glutMouseFunc(mouse);
    glutMainLoop();

}