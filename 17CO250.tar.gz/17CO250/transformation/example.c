#include<GL/glut.h> //includes the opengl, glu, and glut header files
#include<stdlib.h> //includes the standard library header file

float xstart,ystart,xend,r,g,b;
float yend,step,xinc,yinc,x,y;
int check=1;

void keyboard(unsigned char key, int x, int y)
{
     switch(key)
     {
     case 'A':
     case 'a':
          
        xstart=rand()%640;
        ystart=rand()%480;
        
        xend=rand()%640;
        yend=rand()%480;
        
        r=(rand()%9)/8;
        g=(rand()%9)/8;
        b=(rand()%9)/8;
          
          break;    
      case 'u'://to undo the drawing
           
    glClearColor(1, 1, 1, 0); 
    glClear(GL_COLOR_BUFFER_BIT);
      check = 0;
        break;        
     }
glutPostRedisplay();
     }
          
void display(void)
{  
    glColor3f(r,g,b); // sets the current drawing (foreground) color to blue 
    glPointSize(2); // sets the size of points to be drawn (in pixels)
   
    glMatrixMode(GL_PROJECTION);// sets the current matrix to projection
    glLoadIdentity();//multiply the current matrix by identity matrix
    gluOrtho2D(0.0, 640.0, 0.0, 480.0);//sets the parallel(orthographic) projection of the full frame buffer 
     
	glBegin(GL_LINES); // writes pixels on the frame buffer with the current drawing color
       glVertex2i(xstart,ystart);   // sets vertex  
       glVertex2i(xend,yend);  
       
  glEnd();

    glFlush();     // flushes the frame buffer to the screen
}

int main(int argc,char** argv)
{
	glutInit(&argc,argv);

    glutInitWindowSize(640,480);   //sets the width and height of the window in pixels
    glutInitWindowPosition(10,10);//sets the position of the window in pixels from top left corner 
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);//creates a single frame buffer of RGB color capacity.
    glutCreateWindow("DDA Line Drawing");//creates the window as specified by the user as above.
        
    glClearColor(1, 1, 1, 0); // sets the backgraound color to white light
    glClear(GL_COLOR_BUFFER_BIT); // clears the frame buffer and set values defined in glClearColor() function call 
  
    glutDisplayFunc(display);//links the display event with the display event handler(display)
    glutKeyboardFunc(keyboard);//keyboard event handler
    glutMainLoop();//loops the current event
}
