#include<GL/glut.h>
#include<stdio.h> 
#include<stdlib.h>

float factor = 1;
float t1[6], t2[6];


void display(){    
    glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(0.0, 1.0, 0.0);
    glFlush();
}



void keyboard(unsigned char key, int x, int y){
    switch(key){
        
        case 's':
            factor *= 1.5; 
            break;

        case 'r':
            factor /= 1.5;
            break; 

    }
}

void shift(){}


void dda(float px1, float py1, float px2, float py2){

    float dx = px2 - px1;
    float dy = py2 - py1;
    float n = (abs(dx) > abs(dy) ? abs(dx) : abs(dy));


    dx = dx / n, dy = dy / n;
    for(int i = 0 ; i <= n ; i++){        
        glBegin(GL_POINTS);
        glVertex2i(px1, py1);
        px1 += dx;    py1 += dy;
        glEnd();
    }

}

void drawTriangle(float* t, int x, int y){
    float c[6];
    for(int i = 0 ; i < 6 ; i++){
        c[i] = t[i] * factor + (i%2 == 0 ? (float)x : (float)y);
    }
    dda(c[0], c[1], c[2], c[3]);
    dda(c[2], c[3], c[4], c[5]);
    dda(c[0], c[1], c[4], c[5]);

}

void makeStar(int x, int y){


    glBegin(GL_POINTS);
    y = 500 - y;

    drawTriangle(t1, x, y);
    drawTriangle(t2, x, y);

    printf("%d %d\n", x, y);
    glVertex2i(x, y);
    glEnd(); 
    glFlush(); 
}


void mouse(int button, int state, int x, int y){
    switch(button){
	    case GLUT_LEFT_BUTTON:
		    if(state==GLUT_DOWN){
			    makeStar(x, y);
            }
		    break;
	    case GLUT_RIGHT_BUTTON:
		    if(state==GLUT_DOWN){
			    exit(0);
            }
		    break;
	    default:
		    break;
	}
}

void init(){
    glClearColor(0.0, 0.0, 0.0, 0.0);
    glMatrixMode(GL_PROJECTION);
    glPointSize(2);
    gluOrtho2D(0, 500.0, 0, 500.0);
}

int main(int argc,char** argv){

    t1[0] = 0;   t1[1] = 50;
    t1[2] = -30;   t1[3] = -30;
    t1[4] = 30;   t1[5] = -30;

    t2[0] = -35; t2[1] = 30;
    t2[2] = 35;  t2[3] = 30;
    t2[4] = 0;   t2[5] = -50;
    
    

    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(500, 500);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutCreateWindow("Star");
    init();
    glutDisplayFunc(display);
    glutKeyboardFunc(keyboard);
    glutMouseFunc(mouse);
    glutMainLoop();

}