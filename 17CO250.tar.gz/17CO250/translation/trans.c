#include <GL/glut.h>
#include <math.h>
#include <stdlib.h>
#include<stdio.h>

int choice;
float x1, y, x2, y2, sx, sy;


void drawLine(){
    glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(0.0, 1.0, 0.0);
    float xinc = x2 - x1;
    float yinc = y2 - y;
    float n = yinc;
    if(xinc > yinc){
        n = xinc;
    }
    xinc /= n;  yinc /= n;
    for(int i = 0 ; i < n ; i++){
        glBegin(GL_POINTS);
        glVertex2i(x1+0.5, y+0.5);
        glEnd();
        x1 = x1 + xinc;
        y = y + yinc;
    }
    glFlush();
}


void display(){
    if(choice == 1){
        drawLine();
    }else if(choice == 2){

    }else{

    }
}


void init(){
    glClearColor (0.0, 0.0, 0.0, 0.0);
    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    gluOrtho2D(-500.0, 500.0, -500.0, 500.0);      
}



int main(int argc, char **argv) {
  
  printf("Enter 1 for line, 2 for polygon, 3 for circle\n");
  scanf("%d", &choice);
  if(choice == 1){
    printf("Enter x1, y1, x2, y2, sx, sy");
    scanf("%f%f%f%f%f%f", &x1, &y, &x2, &y2, &sx, &sy);
  }else{

  }

  glutInit(&argc, argv);
  glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
  glutInitWindowSize(500, 500);
  glutInitWindowPosition(0, 0);
  glutCreateWindow("translation");
  init();
  glutDisplayFunc(display);
  glutMainLoop();
  return 0;
}