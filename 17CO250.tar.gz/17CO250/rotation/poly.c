#include <GL/glut.h>
#include <stdio.h>
#include <stdlib.h>
#include<math.h>

float *x,*y;
float angle = 0.0;
int n = 3;

void display(){
	glBegin(GL_POLYGON);
	glColor3f(1,0,0);
	for(int i=0;i<n;i++){
		glVertex2f(x[i],y[i]);
	}
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3f(0,1,0);
	for(int i=0;i<n;i++){
        float xnew = x[i] * cos(angle) - y[i] * sin(angle);
        float ynew = x[i] * sin(angle) + y[i] * cos(angle);
		glVertex2f(xnew,ynew);
	}
	glEnd();
	glFlush();
}




void init(){
	glClearColor(0.0, 0.0, 0.0, 0.0);
	glClear(GL_COLOR_BUFFER_BIT);
	gluOrtho2D(-300,300,-300,300);
}

int main(int argc,char* argv[]){

	printf("Enter the number of sides in the polygon\nn : ");
	scanf("%d",&n);
	if(n < 3){
		printf("Value entered too less enter coordinates of a triangle\n");
		n = 3;
	}

	x = (float *)malloc(n*sizeof(float));
	y = (float *)malloc(n*sizeof(float));
	printf("Enter the coordinates in the clockwise direction\n");

	for(int i = 0;i<n;i++){
		printf("Enter the x, y coord of vertex %d\n:",i+1);
		scanf("%f",&x[i]);
		scanf("%f",&y[i]);
		printf("\n");
	}	

	printf("\nEnter angle of rotation in degrees\n");
	scanf("%f", &angle);
    angle *= 0.0174533;
	
	glutInit(&argc,argv);
	glutInitDisplayMode(GLUT_SINGLE|GLUT_RGB);
	glutInitWindowSize(600,600);
	glutInitWindowPosition(0,0);
	glutCreateWindow("Translate-Line");
	init();
	glutDisplayFunc(display);
	glutMainLoop();


}